(function () {
  var state = {
    step: 1,
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    allowWeekends: true,
    locale: undefined,
    outputFormat: 'pipe',
    schoolDays: new Set(),
    mealDays: new Set(),
    disabledDates: new Set(),
    currentMonthOffset: 0
  };

  var dom = {};
  var fieldProps = (typeof fieldProperties !== 'undefined' && fieldProperties) ? fieldProperties : { CURRENT_ANSWER: '' };

  function safeGetPluginParameter(name) {
    if (typeof getPluginParameter === 'function') {
      return getPluginParameter(name);
    }
    var params = new URLSearchParams(window.location.search);
    return params.get(name) || '';
  }

  function safeGetMetaData() {
    if (typeof getMetaData === 'function') {
      return getMetaData();
    }
    return '';
  }

  function safeSetMetaData(value) {
    if (typeof setMetaData === 'function') {
      setMetaData(value);
    }
  }

  function safeSetAnswer(value) {
    if (typeof setAnswer === 'function') {
      setAnswer(value);
    }
  }

  function safeGoToNextField() {
    if (typeof goToNextField === 'function') {
      goToNextField();
    }
  }

  function init() {
    dom.prevMonthBtn = document.getElementById('prevMonthBtn');
    dom.nextMonthBtn = document.getElementById('nextMonthBtn');
    dom.monthLabel = document.getElementById('monthLabel');
    dom.stepBanner = document.getElementById('stepBanner');
    dom.stepMessage = document.getElementById('stepMessage');
    dom.calendarPanel = document.getElementById('calendarPanel');
    dom.reviewPanel = document.getElementById('reviewPanel');
    dom.calendarGrid = document.getElementById('calendarGrid');
    dom.schoolCount = document.getElementById('schoolCount');
    dom.mealCount = document.getElementById('mealCount');
    dom.missingMealList = document.getElementById('missingMealList');
    dom.backBtn = document.getElementById('backBtn');
    dom.continueBtn = document.getElementById('continueBtn');

    bindEvents();
    loadParameters();
    loadExistingValues();
    render();
  }

  function bindEvents() {
    dom.prevMonthBtn.addEventListener('click', function () {
      state.currentMonthOffset = Math.max(-11, state.currentMonthOffset - 1);
      render();
    });

    dom.nextMonthBtn.addEventListener('click', function () {
      state.currentMonthOffset = Math.min(11, state.currentMonthOffset + 1);
      render();
    });

    dom.backBtn.addEventListener('click', function () {
      if (state.step === 2) {
        state.step = 1;
      } else if (state.step === 3) {
        state.step = 2;
      }
      render();
    });

    dom.continueBtn.addEventListener('click', function () {
      if (state.step === 1) {
        if (state.schoolDays.size === 0) {
          dom.stepMessage.textContent = 'Please select at least one school day.';
          return;
        }
        state.step = 2;
        render();
      } else if (state.step === 2) {
        if (state.mealDays.size === 0) {
          dom.stepMessage.textContent = 'Please select at least one meal day.';
          return;
        }
        state.step = 3;
        render();
      } else if (state.step === 3) {
        saveAnswer();
        safeGoToNextField();
      }
    });
  }

  function loadParameters() {
    var yearParam = safeGetPluginParameter('year');
    var monthParam = safeGetPluginParameter('month');
    var allowWeekendsParam = safeGetPluginParameter('allow_weekends');
    var outputFormatParam = safeGetPluginParameter('output_format');
    var localeParam = safeGetPluginParameter('locale');
    var disabledParam = safeGetPluginParameter('disabled_dates') || safeGetPluginParameter('holidays');

    state.year = parseInt(yearParam || new Date().getFullYear(), 10);
    state.month = parseInt(monthParam || (new Date().getMonth() + 1), 10);
    state.allowWeekends = allowWeekendsParam !== 'false' && allowWeekendsParam !== '0';
    state.outputFormat = (outputFormatParam || 'pipe').toLowerCase();
    state.locale = localeParam || undefined;

    if (disabledParam) {
      parseDateList(disabledParam).forEach(function (d) {
        state.disabledDates.add(d);
      });
    }
  }

  function loadExistingValues() {
    var saved = safeGetMetaData();
    var current = fieldProps.CURRENT_ANSWER || '';

    if (saved) {
      try {
        var parsedSaved = JSON.parse(saved);
        if (parsedSaved.school_days || parsedSaved.meal_days) {
          state.schoolDays = new Set(parsedSaved.school_days || []);
          state.mealDays = new Set(parsedSaved.meal_days || []);
          return;
        }
      } catch (e) {}
    }

    if (current) {
      var parsed = parseAnswerValue(current);
      if (parsed) {
        state.schoolDays = new Set(parsed.school_days || []);
        state.mealDays = new Set(parsed.meal_days || []);
      }
    }

    var preloadSchool = safeGetPluginParameter('preload_school_days') || safeGetPluginParameter('school_preload');
    var preloadMeal = safeGetPluginParameter('preload_meal_days') || safeGetPluginParameter('meal_preload');

    if (preloadSchool) {
      parseDateList(preloadSchool).forEach(function (d) {
        state.schoolDays.add(d);
      });
    }

    if (preloadMeal) {
      parseDateList(preloadMeal).forEach(function (d) {
        state.mealDays.add(d);
      });
    }
  }

  function persistDraft() {
    safeSetMetaData(JSON.stringify({
      school_days: Array.from(state.schoolDays).sort(),
      meal_days: Array.from(state.mealDays).sort()
    }));
  }

  function saveAnswer() {
    var output = buildOutput();
    safeSetAnswer(output);
    persistDraft();
  }

  function buildOutput() {
    var schoolList = Array.from(state.schoolDays).sort();
    var mealList = Array.from(state.mealDays).sort();

    if (state.outputFormat === 'json') {
      return JSON.stringify({
        school_days: schoolList,
        meal_days: mealList
      });
    }

    return 'school_days=' + schoolList.join('|') + ';meal_days=' + mealList.join('|');
  }

  function parseAnswerValue(value) {
    if (!value) {
      return null;
    }

    if (value.trim().charAt(0) === '{') {
      try {
        var obj = JSON.parse(value);
        if (obj.school_days || obj.meal_days) {
          return obj;
        }
      } catch (e) {}
    }

    if (value.indexOf('school_days=') !== -1 || value.indexOf('meal_days=') !== -1) {
      var school = [];
      var meal = [];
      var sections = value.split(';');
      sections.forEach(function (section) {
        if (section.indexOf('school_days=') === 0) {
          school = parseDateList(section.replace('school_days=', ''));
        } else if (section.indexOf('meal_days=') === 0) {
          meal = parseDateList(section.replace('meal_days=', ''));
        }
      });
      return { school_days: school, meal_days: meal };
    }

    return null;
  }

  function parseDateList(raw) {
    if (!raw) {
      return [];
    }

    return String(raw)
      .split(/[|,;]/)
      .map(function (item) {
        return item.trim();
      })
      .filter(Boolean);
  }

  function render() {
    var month = getCalendarMonth(state.year, state.month, state.currentMonthOffset);
    state.currentYear = month.year;
    state.currentMonth = month.month;
    dom.monthLabel.textContent = formatMonthLabel(month.year, month.month);

    dom.stepBanner.textContent = getStepTitle(state.step);
    dom.stepMessage.textContent = getStepMessage(state.step);
    dom.backBtn.style.display = state.step === 1 ? 'none' : 'inline-block';
    dom.continueBtn.textContent = state.step === 3 ? 'Confirm' : (state.step === 2 ? 'Review' : 'Continue');
    dom.calendarPanel.hidden = state.step === 3;
    dom.reviewPanel.hidden = state.step !== 3;

    if (state.step === 3) {
      updateReviewSummary();
    }

    renderCalendar();
  }

  function getStepTitle(step) {
    if (step === 1) return 'Step 1: Select School Days';
    if (step === 2) return 'Step 2: Select Meal Days';
    return 'Step 3: Review';
  }

  function getStepMessage(step) {
    if (step === 1) return 'Tap each day the school was open.';
    if (step === 2) return 'Only school days can be selected for meals.';
    return 'Review the selected dates before confirming.';
  }

  function updateReviewSummary() {
    var schoolList = Array.from(state.schoolDays).sort();
    var mealList = Array.from(state.mealDays).sort();
    var missing = schoolList.filter(function (d) {
      return mealList.indexOf(d) === -1;
    });

    dom.schoolCount.textContent = schoolList.length;
    dom.mealCount.textContent = mealList.length;

    dom.missingMealList.innerHTML = '';
    if (missing.length === 0) {
      var li = document.createElement('li');
      li.textContent = 'All school days include meals.';
      dom.missingMealList.appendChild(li);
    } else {
      missing.forEach(function (date) {
        var li = document.createElement('li');
        li.textContent = formatDisplayDate(date);
        dom.missingMealList.appendChild(li);
      });
    }
  }

  function renderCalendar() {
    dom.calendarGrid.innerHTML = '';
    var firstOfMonth = new Date(state.currentYear, state.currentMonth - 1, 1);
    var daysInMonth = new Date(state.currentYear, state.currentMonth, 0).getDate();
    var firstDay = firstOfMonth.getDay();
    var offset = (firstDay + 6) % 7;

    var prevMonthDays = new Date(state.currentYear, state.currentMonth - 1, 0).getDate();
    var totalCells = Math.ceil((offset + daysInMonth) / 7) * 7;

    for (var i = 0; i < totalCells; i++) {
      var cell = document.createElement('button');
      cell.type = 'button';
      cell.className = 'day-cell';

      var dateIndex = i - offset + 1;
      var day = dateIndex;
      var thisMonth = dateIndex >= 1 && dateIndex <= daysInMonth;
      var actualDate = new Date(state.currentYear, state.currentMonth - 1, day);
      var key = formatDateKey(actualDate);

      if (!thisMonth) {
        cell.classList.add('outside-month');
        if (dateIndex <= 0) {
          actualDate = new Date(state.currentYear, state.currentMonth - 2, prevMonthDays + dateIndex + 1);
        } else {
          actualDate = new Date(state.currentYear, state.currentMonth, dateIndex - daysInMonth);
        }
        key = formatDateKey(actualDate);
      }

      var isWeekend = actualDate.getDay() === 0 || actualDate.getDay() === 6;
      var isDisabled = !isWithinMonth(actualDate) || (!state.allowWeekends && isWeekend) || state.disabledDates.has(key);

      if (state.step === 2) {
        isDisabled = !state.schoolDays.has(key) || state.disabledDates.has(key);
      }

      if (isDisabled) {
        cell.classList.add('disabled');
        cell.disabled = true;
      } else {
        cell.addEventListener('click', function (event) {
          var clickedKey = event.currentTarget.dataset.key;
          if (state.step === 1) {
            toggleSet(state.schoolDays, clickedKey);
            state.mealDays = new Set(Array.from(state.mealDays).filter(function (date) {
              return state.schoolDays.has(date);
            }));
          } else if (state.step === 2) {
            toggleSet(state.mealDays, clickedKey);
          }
          persistDraft();
          render();
        });
      }

      if (state.schoolDays.has(key)) {
        cell.classList.add('school-selected');
      }
      if (state.mealDays.has(key)) {
        cell.classList.add('meal-selected');
      }
      if (isWeekend) {
        cell.classList.add('weekend');
      }

      cell.dataset.key = key;
      cell.textContent = actualDate.getDate();
      dom.calendarGrid.appendChild(cell);
    }
  }

  function toggleSet(set, key) {
    if (set.has(key)) {
      set.delete(key);
    } else {
      set.add(key);
    }
  }

  function clearAnswer() {
    state.schoolDays.clear();
    state.mealDays.clear();
    safeSetAnswer('');
    safeSetMetaData('');
    render();
  }

  function handleRequiredMessage(message) {
    if (dom.stepMessage) {
      dom.stepMessage.textContent = message || 'This question is required.';
    }
  }

  window.clearAnswer = clearAnswer;
  window.handleRequiredMessage = handleRequiredMessage;

  function isWithinMonth(date) {
    return date.getFullYear() === state.currentYear && date.getMonth() === state.currentMonth - 1;
  }

  function getCalendarMonth(year, month, offset) {
    var base = new Date(year, month - 1, 1);
    base.setMonth(base.getMonth() + offset);
    return {
      year: base.getFullYear(),
      month: base.getMonth() + 1
    };
  }

  function formatMonthLabel(year, month) {
    var formatter = state.locale ? new Intl.DateTimeFormat(state.locale, { month: 'long', year: 'numeric' }) : new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric' });
    var date = new Date(year, month - 1, 1);
    return formatter.format(date);
  }

  function formatDateKey(date) {
    return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate());
  }

  function formatDisplayDate(key) {
    var date = new Date(key + 'T00:00:00');
    var formatter = state.locale ? new Intl.DateTimeFormat(state.locale, { month: 'short', day: 'numeric', year: 'numeric' }) : new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    return formatter.format(date);
  }

  function pad(value) {
    return String(value).padStart(2, '0');
  }

  init();
})();
