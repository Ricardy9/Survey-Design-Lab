// Logic is embedded in template.html for compatibility.
